// External read-only diagnostics; original proof remains unchanged. Observer overhead is not proof-equivalent.
const { createRequire } = require('node:module');
const { appendFileSync } = require('node:fs');
const path = require('node:path');
const root = process.env.AUDIO_DIAG_ROOT;
const output = process.env.AUDIO_DIAG_TRACE;
if (!root || !output) throw new Error('AUDIO_DIAG_ROOT and AUDIO_DIAG_TRACE required');
const { chromium } = createRequire(path.join(root, 'package.json'))('playwright');
const record = (event, data) => appendFileSync(output, JSON.stringify({ at: new Date().toISOString(), diagnosticOnly: true, event, ...data }) + '\n');
const pages = [];
const seen = new WeakSet();
let snapshot;
async function snapshotAll() {
  let timer;
  try {
    const data = await Promise.race([
      Promise.all(pages.map(async page => {
        try {
          return await page.evaluate(() => ({
            name: localStorage.getItem('emberisle-name'),
            documentIdentity: window.documentIdentity,
            gamePresent: Boolean(window.game),
            hostStateReceived: window.hostFrames?.some(f => f.type === 'state') ?? false,
            soundboardReceived: window.hostFrames?.some(f => f.sound === 'bong') ?? false,
            chatBong: window.game?.getState().chat.some(l => l.sound === 'bong') ?? false,
            media: window.audios?.map((a, id) => ({ id, file: a.src.split('/').at(-1), error: a.error?.code ?? null,
              readyState: a.readyState, currentTime: a.currentTime, baseline: window.mediaTimeBaseline?.[id] ?? 0,
              paused: a.paused, ended: a.ended })),
            events: window.mediaEvents?.slice(-80),
          }));
        } catch (error) { return { snapshotFailed: error.message }; }
      })),
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('read-only snapshot exceeded 1200ms')), 1200); }),
    ]);
    record('post-native-wait-failure', { pages: data });
  } catch (error) { record('snapshot-failed', { message: error.message }); }
  finally { clearTimeout(timer); }
}
function observe(page) {
  if (seen.has(page)) return;
  seen.add(page); pages.push(page);
  const original = page.waitForFunction;
  page.waitForFunction = async function (...args) {
    const nativeWait = args[2]?.timeout === 8000 && String(args[0]).includes('mediaTimeBaseline');
    try { return await original.apply(this, args); }
    catch (error) {
      if (nativeWait) {
        record('native-wait-rejected', { message: error.message });
        snapshot ??= snapshotAll();
        await snapshot;
      }
      throw error;
    }
  };
}
const launch = chromium.launch.bind(chromium);
chromium.launch = async options => {
  const browser = await launch(options);
  record('browser', { version: browser.version(), root });
  const newPage = browser.newPage.bind(browser);
  browser.newPage = async options => { const page = await newPage(options); observe(page); if (process.env.AUDIO_DIAG_CPU_RATE) { const session = await page.context().newCDPSession(page); const rate = Number(process.env.AUDIO_DIAG_CPU_RATE); await session.send('Emulation.setCPUThrottlingRate', { rate }); record('cpu-throttle', { rate }); } return page; };
  const newContext = browser.newContext.bind(browser);
  browser.newContext = async options => { const context = await newContext(options); context.on('page', observe); return context; };
  return browser;
};
