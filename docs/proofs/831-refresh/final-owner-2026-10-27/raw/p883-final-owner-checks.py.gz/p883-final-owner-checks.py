import os,pathlib,subprocess,time,json
root=pathlib.Path('/workspace/p883-final-owner-validation');out=pathlib.Path('/workspace/p883-final-owner-output');out.mkdir(exist_ok=True)
env=os.environ.copy();env.pop('CHROMIUM_PATH',None);env['PLAYWRIGHT_BROWSERS_PATH']='/workspace/emberisle/work/browsers';records=[]
def run(name,cmd):
 t=time.monotonic();print('START '+name,flush=True)
 with (out/(name+'.log')).open('wb') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 record={'name':name,'command':cmd,'exit':r.returncode,'seconds':round(time.monotonic()-t,3)};records.append(record);(out/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True);return r.returncode
for name,cmd in [('typecheck',['npm','run','typecheck']),('registered',['npm','run','registered-prove']),('loosen',['npm','run','loosen-prove','--','--base','e0c559c']),('trade-tabs',['npm','run','trade-tabs-prove']),('hand-cards',['npm','run','hand-cards-prove']),('rotate-overlays',['npm','run','rotate-overlays-prove']),('trade-map',['node','--import','./server/register.mjs','scripts/trade-map.test.mjs']),('build',['npm','run','build']),('size',['node','scripts/size-prove.mjs','--base','/workspace/p883-b-rebuild-base'])]:
 result=run(name,cmd)
 if result and name!='loosen':print('STOP failed '+name,flush=True);break
