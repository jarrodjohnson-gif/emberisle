import os, subprocess, json, pathlib, time, datetime, re, hashlib

root=pathlib.Path('/workspace/p873-main-merge-validation')
out=pathlib.Path('/workspace/p873-merge-output')
out.mkdir(exist_ok=True)
env=os.environ.copy()
env.pop('CHROMIUM_PATH',None)
env['PLAYWRIGHT_BROWSERS_PATH']='/workspace/emberisle/work/browsers'
workflow=(root/'.github/workflows/ci.yml').read_text()
condition=''
presentation=[]
for line in workflow.splitlines():
    if '- if:' in line: condition=line
    match=re.search(r'run: npm run ([\w-]+)',line)
    if match and any("== '"+name+"'" in condition for name in ['presentation','presentation-2','presentation-3','scene-life','scene-water']):
        presentation.append(match.group(1))
names=list(dict.fromkeys(['needs-prove','seat-rail-prove','spiral-prove','connection-health-prove','render-recovery-prove','webgl-recovery-prove','hole-prove']+presentation))
(out/'plan.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'browserPath':env['PLAYWRIGHT_BROWSERS_PATH'],'proofs':names},indent=2)+'\n')
records=[]
for name in names:
    print('START '+name,flush=True)
    started=time.monotonic()
    at=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (out/(name+'.log')).open('wb') as log:
        result=subprocess.run(['npm','run',name],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    record={'proof':name,'command':['npm','run',name],'startedUTC':at,'seconds':round(time.monotonic()-started,3),'exit':result.returncode,'sha256':hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()}
    records.append(record)
    (out/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(record),flush=True)
print('COMPLETE '+str(len(records))+' proofs; failures='+str(sum(r['exit']!=0 for r in records)),flush=True)
