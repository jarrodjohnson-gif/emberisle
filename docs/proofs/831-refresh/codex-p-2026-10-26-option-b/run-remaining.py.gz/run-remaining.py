import subprocess,pathlib,json
p=pathlib.Path('/workspace/883-frozen-output');results={}
for name,cmd in [('hand-cards',['npm','run','hand-cards-prove']),('trade-map',['node','--import','./server/register.mjs','scripts/trade-map.test.mjs']),('trade',['npm','run','trade-prove']),('rotate-overlays',['npm','run','rotate-overlays-prove'])]:
 print('START',name,flush=True)
 with open(p/(name+'.log'),'w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 results[name]=r.returncode;(p/'remaining-status.json').write_text(json.dumps(results,indent=2)+'\n');print('RESULT',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
