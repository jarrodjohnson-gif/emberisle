import os,pathlib,subprocess,time,json,hashlib
candidate=pathlib.Path('/workspace/p883-audio-ci-merge-control');main=pathlib.Path('/workspace/p873-main-df5777b-base');out=pathlib.Path('/workspace/p883-audio-ci-output');out.mkdir(exist_ok=True)
env=os.environ.copy();env.pop('CHROMIUM_PATH',None);env.pop('AUDIO_DIAG_CPU_RATE',None);env['PLAYWRIGHT_BROWSERS_PATH']='/workspace/emberisle/work/browsers';records=[]
def run(name,root,observe):
 print('START '+name,flush=True);t=time.monotonic();extra={};cmd=['node']
 if observe:cmd+=['--require','/workspace/p883-audio-native-observer.cjs'];extra={'AUDIO_DIAG_ROOT':str(root),'AUDIO_DIAG_TRACE':str(out/(name+'.jsonl'))}
 cmd+=['scripts/audio-recovery-prove.mjs']
 with(out/(name+'.log')).open('wb') as log:r=subprocess.run(cmd,cwd=root,env={**env,**extra},stdout=log,stderr=subprocess.STDOUT)
 record={'name':name,'root':str(root),'command':cmd,'observer':observe,'exit':r.returncode,'seconds':round(time.monotonic()-t,3),'proofSha256':hashlib.sha256((root/'scripts/audio-recovery-prove.mjs').read_bytes()).hexdigest()}
 records.append(record);(out/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
run('failed-ci-merge-observed',candidate,True)
run('main-observed',main,True)
proof=candidate/'scripts/audio-recovery-prove.mjs';original=proof.read_bytes();new=subprocess.check_output(['git','show','085756116f36ced4e0abacbb3db5c33d37931355:scripts/audio-recovery-prove.mjs'],cwd='/workspace/emberisle/work/p883-b-sol')
try:
 proof.write_bytes(new);run('same-ci-tree-new-diagnostic-native',candidate,False)
finally:
 proof.write_bytes(original);assert proof.read_bytes()==original
print('COMPLETE controls; original CI proof restored',flush=True)
