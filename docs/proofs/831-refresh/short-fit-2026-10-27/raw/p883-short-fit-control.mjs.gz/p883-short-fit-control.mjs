import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const root=process.env.P883_SHORT_ROOT||'/workspace/p883-final-owner-validation';
const out=process.env.P883_SHORT_OUT||'/workspace/p883-short-fit-before';mkdirSync(out,{recursive:true});
const {chromium}=await import(root+'/node_modules/playwright/index.mjs');const{createServer}=await import(root+'/node_modules/vite/dist/node/index.js');
const fixture=JSON.parse(readFileSync('/workspace/883-final-owner-pictures/fixture.json','utf8')).game;
const vite=await createServer({root,server:{host:'127.0.0.1',port:0},logLevel:'error'});await vite.listen();let browser;const results=[];
try{
 browser=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({viewport:{width:844,height:390},hasTouch:true,isMobile:true});
 await page.addInitScript(()=>{localStorage.setItem('emberisle-name','Jarrod');localStorage.setItem('emberisle-water','simple');localStorage.setItem('emberisle-first-game-coach',JSON.stringify('done'));});
 await page.goto('http://127.0.0.1:'+vite.httpServer.address().port);await page.waitForFunction(()=>window.__emberisle);
 await page.evaluate(game=>{const api=window.__emberisle;api.getState().startAi();api.setState({state:game,localId:'p0',mode:'ai',tradeOpen:false,buildMode:'none',pendingPlace:null,peeking:true,spectator:false,offer:null,declined:[],tradeOutcome:null,tradeTaker:null,error:null,announcement:null,toast:null,net:null});window.__isle?.renderer.setAnimationLoop(null);},fixture);
 await page.getByRole('button',{name:'Trade',exact:true}).click();const panel=page.getByTestId('trade-panel');await panel.waitFor();
 for(const name of ['More Wood to give','More Wood to give','More Brick to give','More Sheep to want','More Stone to want'])await panel.getByRole('button',{name,exact:true}).click();
 for(const family of ['native','Arial','DejaVu Sans','Noto Sans','monospace']){
  await panel.evaluate((el,family)=>{el.style.fontFamily=family==='native'?'':family;},family);
  const result=await panel.evaluate((el)=>{const rect=n=>{const b=n.getBoundingClientRect();return{top:b.top,bottom:b.bottom,height:b.height,width:b.width}};const goods=el.querySelector('.trade-composer-scroll'),footer=el.querySelector('footer'),preview=el.querySelector('[data-testid="trade-player-preview"]');const rows=[...el.querySelectorAll('.trade-half')].map(rect),g=rect(goods),p=getComputedStyle(preview);return {panel:rect(el),goods:g,rows,footer:rect(footer),footerPadding:getComputedStyle(footer).padding,receipt:preview.textContent,receiptBox:rect(preview),font:p.font,fontFamily:p.fontFamily,lineHeight:p.lineHeight,fits:rows.every(r=>r.top>=g.top-.5&&r.bottom<=g.bottom+.5)};});
  const record={family,...result};results.push(record);console.log(JSON.stringify(record));await page.screenshot({path:out+'/'+family.replaceAll(' ','-')+'.png'});
 }
 writeFileSync(out+'/results.json',JSON.stringify({browser:browser.version(),results},null,2)+'\n');
 assert.ok(results.some(r=>r.receiptBox.height>=28),'at least one real wrapped mixed receipt observed');
 if(process.env.P883_SHORT_EXPECT==='pass')assert.ok(results.every(r=>r.fits),'every unchanged goods-row visibility predicate passes');
 else assert.ok(results.some(r=>!r.fits),'controlled wrapped receipt reproduces row clipping');
}finally{await browser?.close();await vite.close();}
