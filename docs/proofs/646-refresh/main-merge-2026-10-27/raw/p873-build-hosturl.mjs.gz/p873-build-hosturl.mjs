import{readdirSync,readFileSync,writeFileSync}from'node:fs';
import{resolve}from'node:path';
import{pathToFileURL}from'node:url';
import{createHash}from'node:crypto';
import{gzipSync}from'node:zlib';
const sizes={};
for(const file of readdirSync('dist/assets').filter(f=>f.endsWith('.js'))){
 const name=file.match(/^(.+)-[A-Za-z0-9_-]{8}\.js$/)?.[1]??file;
 sizes[name]=(sizes[name]??0)+gzipSync(readFileSync('dist/assets/'+file)).length;
}
const file=readdirSync('dist/assets').find(f=>/^table-.*\.js$/.test(f));
const{hostUrl}=await import(pathToFileURL(resolve('dist/assets',file)));
const location={protocol:'http:',hostname:'127.0.0.1',host:'127.0.0.1:45678',search:''};
const data={cwd:process.cwd(),stage:process.argv[2],asset:file,sha256:createHash('sha256').update(readFileSync('dist/assets/'+file)).digest('hex'),fixtureLocation:location,result:hostUrl(location),sizes};
writeFileSync(process.argv[3],JSON.stringify(data,null,2)+'\n');
console.log(JSON.stringify({stage:data.stage,result:data.result,index:sizes.index,SeatNeeds:sizes.SeatNeeds}));
