// Controlled bad run for #1166 (a deliberate mutation, NOT a natural reproduction).
// Once the page navigates to the dead host (ws://127.0.0.1:9), every later fetch of /src/lib/utils.ts is aborted,
// so the host-down reload cannot boot the app. Used only to show the new failure diagnostics print.
import { chromium } from "/home/claude/emberisle/node_modules/playwright/index.mjs";

const launch = chromium.launch.bind(chromium);
chromium.launch = async (...args) => {
  const browser = await launch(...args);
  const newPage = browser.newPage.bind(browser);
  browser.newPage = async (...a) => {
    const page = await newPage(...a);
    let armed = false;
    page.on("request", (r) => {
      if (r.isNavigationRequest() && r.url().includes("ws://127.0.0.1:9")) armed = true;
    });
    await page.route("**/src/lib/utils.ts*", (route) => (armed ? route.abort("failed") : route.continue()));
    return page;
  };
  return browser;
};
