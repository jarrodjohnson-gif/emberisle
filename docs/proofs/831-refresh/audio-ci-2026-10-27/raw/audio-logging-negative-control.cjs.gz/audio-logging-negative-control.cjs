// Synthetic failure of the unchanged native wait: verifies diagnostics never turn a failure green.
const { createRequire } = require('node:module');
const { appendFileSync } = require('node:fs');
const path = require('node:path');
const root = process.env.AUDIO_CONTROL_ROOT;
const output = process.env.AUDIO_CONTROL_TRACE;
const mode = process.env.AUDIO_CONTROL_MODE || 'fulfilled';
if (!root || !output) throw new Error('Control root and trace required');
const { chromium } = createRequire(path.join(root, 'package.json'))('playwright');
const sentinel = new Error('NEGATIVE_CONTROL_NATIVE_WAIT_ORIGINAL_ERROR');
let chosen = false;
let injected = false;
const record = data => appendFileSync(output, JSON.stringify({ mode, ...data }) + '\n');
process.on('uncaughtExceptionMonitor', error => record({ event: 'uncaught', sameOriginalObject: error === sentinel, message: error.message }));
const launch = chromium.launch.bind(chromium);
chromium.launch = async options => {
  const browser = await launch(options);
  const newPage = browser.newPage.bind(browser);
  browser.newPage = async options => {
    const page = await newPage(options);
    const evaluate = page.evaluate;
    page.evaluate = function (fn, ...args) {
      if (injected && String(fn).includes('window.audios')) {
        if (mode === 'rejected') return Promise.reject(new Error('NEGATIVE_CONTROL_SNAPSHOT_REJECTION'));
        if (mode === 'timeout') return new Promise(() => {});
      }
      return evaluate.call(this, fn, ...args);
    };
    const wait = page.waitForFunction;
    page.waitForFunction = async function (...args) {
      if (!chosen && args[2]?.timeout === 8000 && String(args[0]).includes('mediaTimeBaseline')) {
        chosen = true;
        // Real native progress must first satisfy the existing predicate; only then inject a synthetic error.
        await wait.apply(this, args);
        injected = true;
        record({ event: 'injected-after-native-success' });
        throw sentinel;
      }
      return wait.apply(this, args);
    };
    return page;
  };
  return browser;
};
