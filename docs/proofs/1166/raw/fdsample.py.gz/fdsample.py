#!/usr/bin/env python3
"""Passive sampler: every 100 ms, count open fds per Chromium process (by --type) and memfd/shm fds.
Writes one JSON line per sample to argv[1] until argv[2] (a pid) exits."""
import json, os, sys, time

out, watch = sys.argv[1], int(sys.argv[2])
t0 = time.time()
with open(out, "w") as f:
    while os.path.exists(f"/proc/{watch}"):
        rows = []
        for pid in os.listdir("/proc"):
            if not pid.isdigit():
                continue
            try:
                cmd = open(f"/proc/{pid}/cmdline", "rb").read().split(b"\0")
                if not cmd or b"chrom" not in cmd[0]:
                    continue
                kind = next((a.decode()[7:] for a in cmd if a.startswith(b"--type=")), "browser")
                if kind == "utility":
                    sub = next((a.decode() for a in cmd if a.startswith(b"--utility-sub-type=")), "")
                    kind = "utility:" + sub.split(".")[-1][:30]
                fds = os.listdir(f"/proc/{pid}/fd")
                mem = 0
                for fd in fds:
                    try:
                        tgt = os.readlink(f"/proc/{pid}/fd/{fd}")
                    except OSError:
                        continue
                    if "memfd" in tgt or "/dev/shm" in tgt or ".org.chromium" in tgt:
                        mem += 1
                rows.append([int(pid), kind, len(fds), mem])
            except (OSError, StopIteration):
                continue
        f.write(json.dumps({"t": round(time.time() - t0, 2), "p": rows}) + "\n")
        f.flush()
        time.sleep(0.1)
