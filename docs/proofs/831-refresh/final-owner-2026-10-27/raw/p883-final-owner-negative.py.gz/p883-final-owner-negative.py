import os,pathlib,subprocess,json,time
root=pathlib.Path('/workspace/p883-b-rebuild-validation');out=pathlib.Path('/workspace/p883-final-owner-output');proof=root/'scripts/trade-tabs-prove.mjs';original=proof.read_bytes();new=pathlib.Path('/workspace/p883-final-owner-validation/scripts/trade-tabs-prove.mjs').read_bytes();env=os.environ.copy();env.pop('CHROMIUM_PATH',None);env['PLAYWRIGHT_BROWSERS_PATH']='/workspace/emberisle/work/browsers'
for f in ['src/components/game/TradePanel.tsx','src/components/game/TradeResource.tsx','src/components/game/trade-panel.css']:assert (root/f).read_bytes()==subprocess.check_output(['git','show','a51d3cb:'+f],cwd=root)
try:
 proof.write_bytes(new);t=time.monotonic()
 with (out/'old-ui-negative.log').open('wb') as log:r=subprocess.run(['npm','run','trade-tabs-prove'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(out/'old-ui-negative.log').read_text();assert r.returncode==1 and 'final owner footer puts Table left and Bank right' in text
 record={'exit':r.returncode,'seconds':round(time.monotonic()-t,3),'expectedFailure':'final owner footer puts Table left and Bank right','originalRuntime':'a51d3cb','proof':'c002da6'};(out/'old-ui-negative.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
finally:proof.write_bytes(original);assert proof.read_bytes()==original
