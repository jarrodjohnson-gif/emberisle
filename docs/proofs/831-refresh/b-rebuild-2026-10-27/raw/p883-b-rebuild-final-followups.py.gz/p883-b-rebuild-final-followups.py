import os,pathlib,subprocess,time,json,hashlib
root=pathlib.Path('/workspace/p883-b-rebuild-validation');out=pathlib.Path('/workspace/p883-b-rebuild-final-output');out.mkdir(exist_ok=True)
env=os.environ.copy();env.pop('CHROMIUM_PATH',None);env['PLAYWRIGHT_BROWSERS_PATH']='/workspace/emberisle/work/browsers';records=[]
for name,cmd in [('hand-cards',['npm','run','hand-cards-prove']),('rotate-overlays',['npm','run','rotate-overlays-prove']),('owner-pictures',['node','--import',str(root/'server/register.mjs'),'/workspace/p883-b-rebuild-capture-final.mjs'])]:
 print('START '+name,flush=True);t=time.monotonic()
 with(out/(name+'.log')).open('wb') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 record={'name':name,'command':cmd,'cwd':str(root),'exit':r.returncode,'seconds':round(time.monotonic()-t,3),'sha256':hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()}
 records.append(record);(out/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
print('COMPLETE final followups',flush=True)
