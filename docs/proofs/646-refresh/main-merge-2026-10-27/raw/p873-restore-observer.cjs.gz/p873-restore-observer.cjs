// Passive control of the unchanged proof. Timings include observer overhead.
const {createRequire}=require('node:module');
const {appendFileSync}=require('node:fs');
const path=require('node:path');
const root=process.env.RESTORE_CONTROL_ROOT, output=process.env.RESTORE_CONTROL_TRACE;
if(!root||!output) throw new Error('Control paths required');
const {chromium}=createRequire(path.join(root,'package.json'))('playwright');
const record=(kind,data={})=>appendFileSync(output,JSON.stringify({atUTC:new Date().toISOString(),diagnosticOnly:true,proofEquivalent:false,kind,...data})+'\n');
const safeUrl=raw=>{const u=new URL(raw);u.search='';u.hash='';u.username='';u.password='';return u.toString()};
const observed=new WeakSet();
function observe(page){
 if(observed.has(page))return; observed.add(page);
 page.on('requestfailed',r=>record('requestfailed',{url:safeUrl(r.url()),resourceType:r.resourceType(),error:r.failure()?.errorText}));
 page.on('response',r=>{if(r.status()>=400)record('http-error',{url:safeUrl(r.url()),status:r.status()})});
 page.on('pageerror',e=>record('pageerror',{message:e.message}));
 page.on('console',m=>{if(m.type()==='error')record('consoleerror',{message:m.text()})});
 page.on('websocket',s=>{record('socket-open',{url:safeUrl(s.url())});s.on('close',()=>record('socket-close',{url:safeUrl(s.url())}));s.on('framereceived',e=>{try{const m=JSON.parse(String(e.payload));if(m.type==='error')record('socket-error',{url:safeUrl(s.url()),code:m.code??null,message:typeof m.message==='string'?m.message:null})}catch{}})});
 const get=page.getByTestId.bind(page);
 page.getByTestId=function(testId,...args){
  const locator=get(testId,...args);if(testId!=='table-code')return locator;
  const text=locator.textContent.bind(locator);
  locator.textContent=async function(...args){
   try{return await text(...args)}catch(originalError){
    try{
     record('table-code-rejected',{message:originalError.message,url:safeUrl(page.url())});
     let timer;
     try{
      const snapshot=await Promise.race([page.evaluate(()=>{
       const s=window.__emberisle?.getState?.();
       return {appPresent:!!window.__emberisle,readyState:document.readyState,screen:s?.screen??null,mode:s?.mode??null,restoring:s?.restoring??null,netPresent:s?!!s.net:null,error:typeof s?.error==='string'?s.error:null,titleCount:document.querySelectorAll('[data-testid="title-card"]').length,lobbyCount:document.querySelectorAll('[data-testid="table-code"]').length,savedSeatPresent:localStorage.getItem('emberisle-seat')!==null,liveSeatPresent:localStorage.getItem('emberisle-seat-live')!==null};
      }),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Snapshot exceeded1200ms')),1200)})]);
      record('post-failure-snapshot',snapshot);
     }finally{clearTimeout(timer)}
    }catch(e){try{record('snapshot-error',{message:e.message})}catch{}}
    throw originalError;
   }
  };return locator;
 };
}
const launch=chromium.launch.bind(chromium);
chromium.launch=async function(...args){
 const browser=await launch(...args);record('browser',{version:browser.version(),root});
 const context=browser.newContext.bind(browser);
 browser.newContext=async function(...args){const c=await context(...args);c.on('page',observe);return c};
 const page=browser.newPage.bind(browser);
 browser.newPage=async function(...args){const p=await page(...args);observe(p);return p};
 return browser;
};
