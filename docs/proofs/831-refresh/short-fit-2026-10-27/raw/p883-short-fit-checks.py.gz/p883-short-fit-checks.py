import os,pathlib,subprocess,json,time
root=pathlib.Path('/workspace/p883-short-fit-validation');old=pathlib.Path('/workspace/p883-final-owner-validation');out=pathlib.Path('/workspace/p883-short-fit-output');out.mkdir(exist_ok=True);env=os.environ.copy();env.pop('CHROMIUM_PATH',None);env['PLAYWRIGHT_BROWSERS_PATH']='/workspace/emberisle/work/browsers';records=[]
def run(name,cmd,cwd=root,extra={}):
 print('START '+name,flush=True);t=time.monotonic()
 with(out/(name+'.log')).open('wb') as log:r=subprocess.run(cmd,cwd=cwd,env={**env,**extra},stdout=log,stderr=subprocess.STDOUT)
 record={'name':name,'command':cmd,'cwd':str(cwd),'exit':r.returncode,'seconds':round(time.monotonic()-t,3)};records.append(record);(out/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True);return r.returncode
proof=old/'scripts/trade-tabs-prove.mjs';original=proof.read_bytes()
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=old).decode().strip()=='242fdea8634ddb1e12a40c46467cd0c957d2101a'
 proof.write_bytes((root/'scripts/trade-tabs-prove.mjs').read_bytes());code=run('old-runtime-negative',['npm','run','trade-tabs-prove'],old)
 log=(out/'old-runtime-negative.log').read_text();assert code==1 and 'wrapped-receipt table: both goods rows remain visible without scrolling' in log
finally:proof.write_bytes(original);assert proof.read_bytes()==original
for name,cmd,extra in [('wrapped-font-controls',['node','/workspace/p883-short-fit-control.mjs'],{'P883_SHORT_ROOT':str(root),'P883_SHORT_OUT':'/workspace/p883-short-fit-after','P883_SHORT_EXPECT':'pass'}),('typecheck',['npm','run','typecheck'],{}),('registered',['npm','run','registered-prove'],{}),('loosen',['npm','run','loosen-prove','--','--base','242fdea'],{}),('trade-tabs',['npm','run','trade-tabs-prove'],{}),('rotate-overlays',['npm','run','rotate-overlays-prove'],{}),('owner-pictures',['node','--import','./server/register.mjs','/workspace/p883-short-fit-owner-capture.mjs'],{}),('build',['npm','run','build'],{}),('size',['node','scripts/size-prove.mjs','--base','/workspace/p883-b-rebuild-base'],{})]:
 if run(name,cmd,extra=extra):print('STOP failed '+name,flush=True);break
