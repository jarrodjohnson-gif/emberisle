import subprocess,pathlib,json,os
p=pathlib.Path('/workspace/883-frozen-output');results={}
commands=[('trade-tabs',['npm','run','trade-tabs-prove']),('client',['npm','run','client-prove']),('hand-cards',['npm','run','hand-cards-prove']),('trade-map',['node','--import','./server/register.mjs','scripts/trade-map.test.mjs']),('trade',['npm','run','trade-prove']),('rotate-overlays',['npm','run','rotate-overlays-prove'])]
for name,cmd in commands:
 print('START',name,flush=True)
 with open(p/(name+'.log'),'w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 results[name]=r.returncode;(p/'browser-status.json').write_text(json.dumps(results,indent=2)+'\n');print('RESULT',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
