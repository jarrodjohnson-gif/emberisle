// Manual diagnostic only. No application/proof edits; original bounding box is returned unchanged.
const { createRequire } = require('node:module');
const { appendFileSync, realpathSync } = require('node:fs');
const path = require('node:path');
const root = process.env.WAYFARER_DIAG_ROOT;
const log = process.env.WAYFARER_DIAG_LOG;
if (!root || !log) throw new Error('Set WAYFARER_DIAG_ROOT and WAYFARER_DIAG_LOG');
const req = createRequire(path.join(root, 'package.json'));
const modulePath = realpathSync(req.resolve('playwright'));
const { chromium } = req('playwright');
const emit = record => appendFileSync(log, JSON.stringify(record) + '\n');
emit({event:'preload', modulePath, root:realpathSync(root), pid:process.pid});
const launch = chromium.launch;
chromium.launch = async function (...args) {
  const browser = await launch.apply(this, args);
  const newContext = browser.newContext;
  browser.newContext = async function (...contextArgs) {
    const context = await newContext.apply(this, contextArgs);
    const newPage = context.newPage;
    context.newPage = async function (...pageArgs) {
      const page = await newPage.apply(this, pageArgs);
      const proto = Object.getPrototypeOf(page.locator('[data-testid="fortune-play-knight"]'));
      if (!Object.hasOwn(proto, '__wayfarerDiagnostic')) {
        const boundingBox = proto.boundingBox;
        Object.defineProperty(proto, '__wayfarerDiagnostic', { value: true });
        proto.boundingBox = async function (...boxArgs) {
          const result = await boundingBox.apply(this, boxArgs);
          if (!String(this._selector).includes('fortune-play-knight')) return result;
          const viewport = this.page().viewportSize();
          const measuredAt = Date.now();
          emit({event:'boundingBox', measuredAt, selector:this._selector, viewport, box:result,
            checks:result && viewport ? {width44:result.width>=44,height44:result.height>=44,top:result.y>=0,bottom:result.y+result.height<=viewport.height} : null});
          try {
            const snapshot = await this.evaluate(el => {
              const rect = node => { const r=node.getBoundingClientRect(); return {x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom}; };
              const nodes=[];
              for(let node=el; node && node instanceof HTMLElement; node=node.parentElement) {
                const css=getComputedStyle(node);
                nodes.push({tag:node.tagName,testid:node.dataset.testid||null,rect:rect(node),transform:css.transform,animationName:css.animationName,animationDuration:css.animationDuration,animationPlayState:css.animationPlayState,animations:node.getAnimations().map(a=>({playState:a.playState,currentTime:a.currentTime}))});
              }
              return {sampleAt:Date.now(),innerWidth,innerHeight,nodes};
            });
            emit({event:'later-read-only-style-snapshot',measuredAt,snapshot});
          } catch (error) { emit({event:'snapshot-error',measuredAt,error:String(error)}); }
          return result;
        };
      }
      return page;
    };
    return context;
  };
  return browser;
};
