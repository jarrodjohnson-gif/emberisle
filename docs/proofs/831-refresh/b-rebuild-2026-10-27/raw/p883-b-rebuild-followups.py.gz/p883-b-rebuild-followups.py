import os,pathlib,subprocess,time,json,hashlib
root=pathlib.Path('/workspace/p883-b-rebuild-validation')
old=pathlib.Path('/workspace/p883-b-frozen-validation')
out=pathlib.Path('/workspace/p883-b-rebuild-output');out.mkdir(exist_ok=True)
env=os.environ.copy();env.pop('CHROMIUM_PATH',None);env['PLAYWRIGHT_BROWSERS_PATH']='/workspace/emberisle/work/browsers'
records=[]
def run(name,cmd,cwd=root):
 print('START '+name,flush=True);t=time.monotonic()
 with(out/(name+'.log')).open('wb') as log:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 record={'name':name,'command':cmd,'cwd':str(cwd),'exit':r.returncode,'seconds':round(time.monotonic()-t,3),'sha256':hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()}
 records.append(record);(out/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
 return r.returncode
proof=old/'scripts/trade-tabs-prove.mjs';original=proof.read_bytes()
for p in ['src/components/game/TradePanel.tsx','src/components/game/TradeResource.tsx','src/components/game/trade-panel.css']:
 assert (old/p).read_bytes()==subprocess.check_output(['git','show','c9eacc4:'+p],cwd=root)
try:
 proof.write_bytes((root/'scripts/trade-tabs-prove.mjs').read_bytes())
 run('old-ui-negative-control',['npm','run','trade-tabs-prove'],old)
finally:
 proof.write_bytes(original)
 assert proof.read_bytes()==original
run('hand-cards',['npm','run','hand-cards-prove'])
run('rotate-overlays',['npm','run','rotate-overlays-prove'])
run('owner-pictures',['node','--import',str(root/'server/register.mjs'),'/workspace/p883-b-rebuild-capture.mjs'])
print('COMPLETE serial followups',flush=True)
