#!/bin/bash
# usage: memrun.sh LIMIT_MB  — run the unchanged client-prove in the t1166 memory cgroup with the passive observer
S=/tmp/claude-0/-home-claude/b60c1c3b-4312-56d3-8944-43c06648cbc5/scratchpad
M=/sys/fs/cgroup/memory/process_api/01a18f98-33d4-745a-a1e9-083e297a3e60/claude-code-bash/t1166
L=$1; cd /home/claude/emberisle
echo ${L}M > $M/memory.limit_in_bytes; echo 0 > $M/memory.failcnt; o0=$(awk '/oom_kill /{print $2}' $M/memory.oom_control)
rm -f $S/obsm$L.jsonl
bash -c "echo \$\$ > $M/tasks; OBS_OUT=$S/obsm$L.jsonl exec node --import $S/observer.mjs scripts/client-prove.mjs" > $S/mem$L.log 2>&1
echo "L=$L exit=$? failcnt=$(cat $M/memory.failcnt) new_oom_kills=$(( $(awk '/oom_kill /{print $2}' $M/memory.oom_control) - o0 ))"
grep -n "host down\|client prove ok\|^FAIL" $S/mem$L.log | cut -c1-200
python3 - $S/obsm$L.jsonl <<'EOF'
import json,sys,collections
try: ev=[json.loads(l) for l in open(sys.argv[1])]
except FileNotFoundError: ev=[]
navs=[e for e in ev if e['k']=='nav']; f=[e for e in ev if e['k']=='failed']
print(' navs',len(navs),'failed',len(f),collections.Counter(e['err'] for e in f).most_common(4))
if f:
    first=f[0]['t']; i=max(k for k,n in enumerate(navs) if n['t']<=first)
    print(' first failure in nav #%d of %d (%s), types %s'%(i+1,len(navs),navs[i]['url'][-40:],collections.Counter(e['type'] for e in f)))
    print(' sample',[e['url'][-35:] for e in f[:5]])
EOF
