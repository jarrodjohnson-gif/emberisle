import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { chromium } from "/workspace/p905-main017-base/node_modules/playwright/index.mjs";
import { createServer } from "/workspace/p905-main017-base/node_modules/vite/dist/node/index.js";

const out = "/workspace/905-lobby-compare/code-width";
mkdirSync(out, { recursive: true });
const rooms = mkdtempSync(path.join(tmpdir(), "emberisle-1103-rooms-"));
const host = spawn(process.execPath, ["--import", "./register.mjs", "host.mjs"], {
  cwd: "/workspace/p905-main017-base/server",
  env: { ...process.env, PORT: "0", ROOMS_DIR: rooms },
});
const hostPort = await new Promise((resolve, reject) => {
  host.on("error", reject);
  host.stdout.on("data", d => {
    const m = String(d).match(/listening (\d+)/);
    if (m) resolve(Number(m[1]));
  });
  host.on("exit", code => reject(new Error(`host exited ${code}`)));
});
const vite = await createServer({ root: "/workspace/p905-main017-base", server: { host: "127.0.0.1", port: 0 }, logLevel: "error" });
await vite.listen();
const url = `http://127.0.0.1:${vite.httpServer.address().port}/?host=ws://127.0.0.1:${hostPort}`;
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || (existsSync("/opt/pw-browsers/chromium") ? "/opt/pw-browsers/chromium" : undefined),
  args: ["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"],
});
const errors = [];
const results = [];
async function client(name, viewport, touch) {
  const context = await browser.newContext({ viewport, hasTouch: touch, isMobile: touch, deviceScaleFactor: 1, reducedMotion: "reduce" });
  const page = await context.newPage();
  page.on("pageerror", e => errors.push(String(e)));
  page.on("console", m => { if (m.type() === "error") errors.push(m.text()); });
  await page.addInitScript(n => {
    localStorage.setItem("emberisle-name", n);
    localStorage.setItem("emberisle-jelly", "lite");
    window.__copies = [];
    Object.defineProperty(navigator, "clipboard", { value: { writeText: async text => { window.__copies.push(text); } } });
  }, name);
  await page.goto(url);
  await page.waitForFunction(() => !!window.__emberisle);
  return page;
}

try {
 const page=await client('Jarrod',{width:375,height:667},true);
 await page.evaluate(()=>window.__emberisle.getState().hostTable());
 await page.getByTestId('lobby-card').waitFor();
 await page.evaluate(()=>document.fonts.ready);
 const original=await page.getByTestId('table-code').textContent();
 const records=[];
 for(const code of [original.trim(),'JJJJ','WWWW','MMMM','TTTT','ZZZZ','8888']) {
  await page.evaluate(code=>window.__emberisle.setState({code}),code);
  await page.waitForFunction(code=>document.querySelector('[data-testid="table-code"]').textContent.trim()===code,code);
  const sample=await page.evaluate(()=>{
   const header=document.querySelector('.lobby-header');const code=document.querySelector('[data-testid="table-code"]');
   return {code:code.textContent.trim(),headerWidth:header.getBoundingClientRect().width,codeWidth:code.getBoundingClientRect().width,buttons:[...header.querySelectorAll('button')].map(el=>{const r=document.createRange();r.selectNodeContents(el);const t=r.getBoundingClientRect();const b=el.getBoundingClientRect();const s=getComputedStyle(el);return{label:el.textContent.trim(),width:b.width,textWidth:t.width,padL:t.left-b.left,padR:b.right-t.right,cssPadding:s.padding,font:s.font,fontFamily:s.fontFamily,flexShrink:s.flexShrink}})};
  });
  records.push(sample);console.log(JSON.stringify(sample));
 }
 writeFileSync(out+'/records.json',JSON.stringify({diagnosticOnly:true,fixture:'real host lobby; local display code changed only; no join attempts with fixture code',records},null,2)+'\n');
 console.log('code-width diagnostic complete');
}finally{await browser.close();await vite.close();host.kill();}
