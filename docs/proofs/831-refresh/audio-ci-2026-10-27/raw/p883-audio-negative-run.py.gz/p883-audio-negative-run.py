import os,pathlib,subprocess,json,time
root=pathlib.Path('/workspace/p883-audio-ci-merge-control');out=pathlib.Path('/workspace/p883-audio-ci-output');proof=root/'scripts/audio-recovery-prove.mjs';original=proof.read_bytes();new=subprocess.check_output(['git','show','0857561:scripts/audio-recovery-prove.mjs'],cwd='/workspace/emberisle/work/p883-b-sol');records=[]
env=os.environ.copy();env.pop('CHROMIUM_PATH',None);env['PLAYWRIGHT_BROWSERS_PATH']='/workspace/emberisle/work/browsers'
try:
 proof.write_bytes(new)
 for mode in ['fulfilled','rejected','timeout']:
  trace=out/('negative-'+mode+'.jsonl');log=out/('negative-'+mode+'.log');t=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(['node','--require','/workspace/audio-logging-negative-control.cjs','scripts/audio-recovery-prove.mjs'],cwd=root,env={**env,'AUDIO_CONTROL_ROOT':str(root),'AUDIO_CONTROL_TRACE':str(trace),'AUDIO_CONTROL_MODE':mode},stdout=f,stderr=subprocess.STDOUT)
  events=[json.loads(l) for l in trace.read_text().splitlines()];assert r.returncode==1 and any(e.get('sameOriginalObject') is True for e in events)
  snaps=[json.loads(l.split(' ',1)[1]) for l in log.read_text().splitlines() if l.startswith('RECOVERY_WAIT_FAILURE ')];assert len(snaps)==3 and all(s['status']==mode for s in snaps)
  record={'mode':mode,'exit':r.returncode,'originalErrorObjectPreserved':True,'snapshots':[s['status'] for s in snaps],'seconds':round(time.monotonic()-t,3)};records.append(record);print(json.dumps(record),flush=True)
 (out/'negative-results.json').write_text(json.dumps(records,indent=2)+'\n')
finally:proof.write_bytes(original)
