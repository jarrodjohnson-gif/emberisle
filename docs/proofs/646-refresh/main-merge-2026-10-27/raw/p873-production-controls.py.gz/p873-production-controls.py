import os,pathlib,subprocess,json,time,datetime,hashlib
root=pathlib.Path('/workspace/p873-main-merge-validation')
base=pathlib.Path('/workspace/p873-main-df5777b-base')
out=pathlib.Path('/workspace/p873-merge-output')
env=os.environ.copy();env.pop('CHROMIUM_PATH',None)
env['PLAYWRIGHT_BROWSERS_PATH']='/workspace/emberisle/work/browsers'
records=[]
def run(name,cmd,cwd=root,extra=None):
    print('START '+name,flush=True)
    start=time.monotonic();at=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with(out/(name+'.log')).open('wb') as log:
        r=subprocess.run(cmd,cwd=cwd,env={**env,**(extra or {})},stdout=log,stderr=subprocess.STDOUT)
    record={'name':name,'command':cmd,'cwd':str(cwd),'startedUTC':at,'seconds':round(time.monotonic()-start,3),'exit':r.returncode,'sha256':hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()}
    records.append(record);(out/'production-control-results.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
    return r.returncode
run('changed-build-observed-restore',['node','--require','/workspace/p873-restore-observer.cjs','scripts/restore-prove.mjs'],extra={'RESTORE_CONTROL_ROOT':str(root),'RESTORE_CONTROL_TRACE':str(out/'changed-build-observer.jsonl')})
if run('production-rebuild',['npm','run','build']):raise SystemExit('Production rebuild failed; later controls unrun')
run('production-hosturl',['node','/workspace/p873-build-hosturl.mjs','fresh-production-rebuild',str(out/'production-build.json')])
run('production-restore',['npm','run','restore-prove'])
run('production-chunk-fail',['npm','run','chunk-fail-prove'])
run('production-version',['npm','run','version-prove'])
run('main-production-restore',['npm','run','restore-prove'],base)
run('server-needs',['node','--import','./server/register.mjs','server/needs-prove.mjs'])
run('production-size',['node','scripts/size-prove.mjs','--base',str(base)])
paths=subprocess.check_output(['git','ls-files','src','scripts','server','package.json','package-lock.json','.github/workflows/ci.yml'],cwd=root,text=True).splitlines()
hashes={}
for p in paths:
    b=(root/p).read_bytes();frozen=subprocess.check_output(['git','show','HEAD:'+p],cwd=root)
    if b!=frozen:raise SystemExit('Tracked source changed: '+p)
    hashes[p]=hashlib.sha256(b).hexdigest()
(out/'tracked-source-after.json').write_text(json.dumps(hashes,sort_keys=True,indent=2)+'\n')
print('COMPLETE controls; all'+str(len(paths))+' tracked source files match HEAD',flush=True)
