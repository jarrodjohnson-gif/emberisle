# Shared focus regression control

parent: Codex-p

The shared `focusableIn` helper affects every dialog using `useFocusTrap`, not only trading.
The additive existing client proof tests WinScreen with its Look around button temporarily assigned `tabindex=-1`.
All earlier positive Tab/Shift+Tab assertions and later WinScreen behavior remain unchanged.
The fixture restores the original attribute before continuing.

## Negative control

Source: private proof checkpoint `35a2e1265cbd5c1c14b33fd69cd1ceb95509128e`.
An isolated frozen validation checkout removed only ` && el.tabIndex >= 0` from `focusableIn`.
No mutation was committed or pushed.

Command, run alone under the shared browser lock:

```sh
env -u CHROMIUM_PATH PLAYWRIGHT_BROWSERS_PATH=/workspace/emberisle/work/browsers flock /tmp/emberisle-team-browser.lock npm run client-prove
```

Actual exit: **1**, at the new intended assertion:

```text
win negative tabindex: {"afterTab":{"id":"win-look","inDialog":true},"afterShiftTab":{"id":"win-menu","inDialog":true}}
FAIL win screen: negative tabindex button entered the Tab sequence: {"afterNegativeTab":{"id":"win-look","inDialog":true},"afterNegativeShiftTab":{"id":"win-menu","inDialog":true}}
```

The process ended before restoration. The original focus-trap bytes were restored and the checkout was clean.
Restored SHA256: `e36dba409562b9b53fb4e3e736854b05f3ef9aa381131ece8a31f00d5969b68a`.
Chromium153.0.8010.12, Playwright1.63 revision1243; Node24.19.0.

Full normal candidate validation follows separately; this control does not claim a passing suite.
The earlier unexplained client restore failure remains tracked in #1166.
